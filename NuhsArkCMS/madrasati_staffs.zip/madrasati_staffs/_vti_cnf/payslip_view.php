vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Mar 2020 04:34:18 -0000
vti_extenderversion:SR|12.0.0.6500
vti_author:SR|LAPTOP-3VENH845\\Administrator
vti_modifiedby:SR|LAPTOP-3VENH845\\Administrator
vti_timecreated:TR|03 Feb 2020 12:38:58 -0000
vti_title:SR|Nuh's Ark Islamic Montessori School
vti_nexttolasttimemodified:TW|30 Mar 2020 04:34:07 -0000
vti_backlinkinfo:VX|madrasati_staffs/payslip_summary.php
vti_cacheddtm:TX|30 Mar 2020 04:34:18 -0000
vti_filesize:IR|11058
vti_cachedtitle:SR|Nuh's Ark Islamic Montessori School
vti_cachedbodystyle:SR|<body style="background-color: #C0C0C0">
vti_cachedlinkinfo:VX|Q|../css/style.css S|../images/logo_madrasati.png
vti_cachedsvcrellinks:VX|FQUS|css/style.css FSUS|images/logo_madrasati.png
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8
vti_charset:SR|utf-8
