vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|05 Mar 2020 10:41:47 -0000
vti_extenderversion:SR|12.0.0.6500
vti_author:SR|LAPTOP-3VENH845\\Administrator
vti_modifiedby:SR|LAPTOP-3VENH845\\Administrator
vti_timecreated:TR|30 Jan 2020 06:03:47 -0000
vti_nexttolasttimemodified:TR|05 Mar 2020 10:41:39 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|05 Mar 2020 10:41:38 -0000
vti_filesize:IR|236
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
