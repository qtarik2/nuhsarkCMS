vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Mar 2020 09:17:24 -0000
vti_extenderversion:SR|12.0.0.6500
vti_author:SR|LAPTOP-3VENH845\\Administrator
vti_modifiedby:SR|LAPTOP-3VENH845\\Administrator
vti_timecreated:TR|03 Feb 2020 02:59:37 -0000
vti_title:SR|Nuh's Ark Islamic Montessori School
vti_nexttolasttimemodified:TW|05 Mar 2020 10:52:58 -0000
vti_backlinkinfo:VX|madrasati_staffs/staff_manage-account.php madrasati_staffs/index.php madrasati_staffs/staff-directory.php madrasati_staffs/student_manage-account_details.php madrasati_staffs/payslip_summary.php madrasati_staffs/student_manage-account.php madrasati_staffs/staff_manage-account_update-account.php
vti_cacheddtm:TX|11 Mar 2020 09:17:24 -0000
vti_filesize:IR|8214
vti_cachedtitle:SR|Nuh's Ark Islamic Montessori School
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css S|https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js S|https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js Q|https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css S|../images/logo_madrasati.png K|student_manage-account.php H|index.php K|student_manage-account.php H|payslip_summary.php H|student_manage-account.php H|staff-directory.php K|student_manage-account.php H|staff_manage-account.php K|student_manage-account.php H|logout.php Q|../css/style.css H|logout.php Q|../css/style.css H|student_manage-account_details.php
vti_cachedsvcrellinks:VX|NQSS|https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css NSSS|https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js NSSS|https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js NQSS|https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css FSUS|images/logo_madrasati.png FKUS|madrasati_staffs/student_manage-account.php FHUS|madrasati_staffs/index.php FKUS|madrasati_staffs/student_manage-account.php FHUS|madrasati_staffs/payslip_summary.php FHUS|madrasati_staffs/student_manage-account.php FHUS|madrasati_staffs/staff-directory.php FKUS|madrasati_staffs/student_manage-account.php FHUS|madrasati_staffs/staff_manage-account.php FKUS|madrasati_staffs/student_manage-account.php FHUS|madrasati_staffs/logout.php FQUS|css/style.css FHUS|madrasati_staffs/logout.php FQUS|css/style.css FHUS|madrasati_staffs/student_manage-account_details.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8
vti_charset:SR|utf-8
