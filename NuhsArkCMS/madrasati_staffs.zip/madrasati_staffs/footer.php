    <footer class="footer">
        <div class="row">
            <div class="col-md-3 align-self-center">
                <p>Madrasati Montessori Primary School</p>
            </div>
            <div class="col align-self-center">
                <p>2A, Jalan Jasper 7/15, Seksyen 7, Shah Alam, Selangor Darul Ehsan, Malaysia.</p>
            </div>
            <div class="col align-self-center">
                <p class="text-right">&nbsp;&nbsp;<i class="fas fa-link"></i>&nbsp;<a href="https://www.madrasati.edu.my" style="color: rgb(255,255,255);">madrasati.edu.my</a></p>
            </div>
        </div>
    </footer>
</body>
</html>
