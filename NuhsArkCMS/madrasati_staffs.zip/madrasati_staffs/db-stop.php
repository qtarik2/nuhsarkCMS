﻿<?php
/*

*/


$con = mysqli_connect("localhost:3306","simflightkl","Sfkl#2019","simflightkl_promo");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  echo "System Migration to https://www.simflightkl.com.my/cms";
  }
?>