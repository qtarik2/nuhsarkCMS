<?php
require('makefont/makefont.php');

MakeFont('C:\\Windows\\Fonts\\calibrib.ttf','cp1252');
?>